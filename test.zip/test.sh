#!/bin/bash

notify-send "I am EVIL"
