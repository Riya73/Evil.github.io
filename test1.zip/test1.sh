#!/bin/bash

# Simulate  hacking animation
echo "Starting hacking script..."
sleep 2

echo "Connecting to the secure server..."
sleep 3

echo "[########              ] 45% connected"
sleep 2

echo "[###################   ] 90% connected"
sleep 2

echo "[#######################] 100% connected!"
sleep 1

echo "Accessing restricted files..."
sleep 2

# Fake error messages to make it dramatic
echo "ERROR: Failed to decrypt the mainframe"
sleep 2

echo "Retrying..."
sleep 3

cho "SUCCESS: Decryption complete!"
sleep 2

echo "Downloading secret files..."
for i in {1..100}; do
  echo "Downloading file $i of 100..."
  sleep 0.1
done

echo "Download complete!"
sleep 2

echo "Self-destruct initiated. Goodbye."
sleep 5

# Fun message at the end
echo "Gotcha you Motu
