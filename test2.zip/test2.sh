#!/bin/bash

# Fun prank shell script
# Endless loop displaying harmless messages

while true; do
    # Randomly display messages to confuse your friend
    case $((RANDOM % 5)) in
        0)
            notify-send "Uh oh!" "Your system is being taken over!"
            ;;
        1)
            notify-send "Virus Alert!" "Just kidding, but it's fun!"
            ;;
        2)
            notify-send "System Hack!" "Oops... something is not right!"
            ;;
        3)
            xdg-open https://www.youtube.com/watch?v=dQw4w9WgXcQ  # Rickroll them
            ;;
        4)
            notify-send "Warning!" "You should  not lie to me !"
            ;;
    esac

    # Random sleep time to make it more unpredictable
    sleep $((RANDOM % 10 + 2))  # Sleep between 2-12 seconds
done
