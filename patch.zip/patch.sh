#!/bin/bash

zenity --error --text="You are hacked, my friend"
